$("#example").tableHTMLExport({

    // csv, txt, json, pdf
    type:'json',
  
    // file name
    filename:'sample.json'
    
  });